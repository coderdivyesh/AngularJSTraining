var app = angular.module('mainModule' ,['sermodule'])
app.controller('userController',function($scope,userservice){
	
	$scope.names=userservice.showUsers();
	
	
	
	$scope.addUser=function(){
		
		userservice.addUser($scope.contact)
		
		$scope.contact={};
	}
	
	
$scope.editUser=function(id){
		
	$scope.contact=userservice.editUser(id);
	
	/*$scope.contact=c;*/
		
	}
	

$scope.deleteUser=function(id){
	
	userservice.deleteUser(id)
	
	
}
});

app.directive('myPicker', function() {
    return {
        restrict: 'A',
        require:'ngModel',
       
        link : function (scope, element, attrs, ngModelCtrl) {
            $(function(){
                element.datepicker({
                    dateFormat:'dd/mm/yy',
                    onSelect:function (doj) {
                        ngModelCtrl.$setViewValue(doj);
						
                        scope.$digest();
                    }
                });
            });
        }
    }
});

app.directive('passCompare', [function () {
	 return {
	           require: 'ngModel',
	           link: function (scope, elem, attrs, ctrl) {
	                 var firstfield = "#" + attrs.passCompare;
		 
	                 //second field key up
	                 elem.on('keyup', function () {
	                 scope.$apply(function () {
	                 var isMatch = elem.val() === $(firstfield).val();
	                 ctrl.$setValidity('valueMatch', isMatch);
					 console.log(firstfield);
	                 });
	                 });

	                 
	               }
	         }
	 }]);



