var myApp = angular.module('myApp',['ngRoute','mainModule']);

myApp.config(function($routeProvider, $locationProvider) {
	
    $routeProvider.
      when('/login', {
	templateUrl: 'partials/login.html',
	controller: 'LoginController'
      }).
      when('/register', {
	templateUrl: 'partials/registration.html',
	controller: 'userController'
      }).
      otherwise({
	redirectTo: '/login'
      });
});

myApp.run(function($rootScope, $location) {

    $rootScope.$on( "$routeChangeStart", function() {
      if ($rootScope.loggedInUser == null) {
         
          $location.path("/login");
      
      }
    });
  });
  
myApp.controller("LoginController", function($scope, $location, $rootScope) {
  $scope.login = function() {
    $rootScope.loggedInUser = $scope.username;
    $location.path("/register");
  };
});