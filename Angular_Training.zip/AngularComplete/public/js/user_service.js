angular.module('sermodule' ,[])
.service('userservice',function($http){
	
	var contacts=[];
	var uid=1;

	this.showUsers=function(){
		
		return contacts;
	}
	
	this.addUser= function(contact){
		
		if(contact.id == null){
			contacts.id = uid++;
			
			$http.post('/savemydata',contact).success(function(data){
				contacts.push(data); 
			});
			
		}
		else{
		for(i in contacts){
			if(contacts[i].id == contact.id){
				contacts[i] = contact;
			}
			
			
		}
	}
}

	
	this.deleteUser= function(id){
		
		for(i in contacts){
			if(contacts[i].id == id){
				
				contacts.splice(i,1);
				contact={};
			}
			
		}
		
		
	}
	
	
	
	this.editUser= function(id){
		
		for(i in contacts){
			
			if(contacts[i].id == id){
				return contacts[i];
			}
		}
		
		
		
	}
});


