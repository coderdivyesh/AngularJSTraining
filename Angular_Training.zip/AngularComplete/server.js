var express = require('express');
var bp = require('body-parser');
var _ = require('underscore');
var MongoClient = require('mongodb').MongoClient;


var app = express();
var db 
app.use(bp.json());

/*MongoClient.connect('mongodb://admin:admin@ds023435.mlab.com:23435/customerni',
		function(err,mydb){
	if (err) return console.log(err)
	db = mydb
});
*/

var todos = [];

app.post ('/savemydata', function (req,res){
var body = _.pick(req.body,'id','name','email','doj','income');

body.id=parseInt(body.id,10);
body.name=body.name;
body.email=body.email;
body.doj=body.doj;
body.income=body.income;


todos.push(body);

res.json(body);

});

app.get ('/getmydata', function (req,res){
	res.json(todos);
	
});



app.use(express.static('public'));

app.listen(3000,function(){
	console.log('Express server is up on port 3000');
});