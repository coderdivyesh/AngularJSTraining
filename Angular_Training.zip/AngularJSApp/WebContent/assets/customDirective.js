<!DOCTYPE html>
 
<meta name="robots" content="noindex">
<html>
<head>
<script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.3.2/angular.min.js"></script>
<script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
<title>AngularJS Custom Directive</title> 
<style id="jsbin-css">
.help-block
{
  color:red;
}
</style>
</head>
<body ng-app="app">
 <div ng-controller="Ctrl">
 <form name="userForm" ng-submit="submitForm()" novalidate>
 <h2>Custom Directive to compare textboxes values</h2>
 <table>
    <!-- Password -->
   <tr>    
     <td>Password</td>
     <td><input type="Password" name="password" id="passid"  ng-model="user.password" placeholder="Password" ng-required="true">
 
       <span ng-show="userForm.password.$invalid" class="help-block">Password is required</span>
     </td>
   </tr>
   <!-- Confirm Password -->
    <tr>
     <td>Confirm Password</td>
     <td><input type="Password" name="confirmPassword" class="form-control" ng-model="user.confirmPassword" placeholder="Confirm Password" ng-compare="passid" ng-required="true">
 
       <span ng-show="userForm.confirmPassword.$error.required" class="help-block">Confirm password is required</span>
 
       <span ng-show="userForm.confirmPassword.$error.valueMatch && !userForm.confirmPassword.$error.required" class="help-block">Confirm password doesn't match</span>
      </td>
   </tr>
    <!-- Submit Form -->
    <tr>
      <td></td>
     <td>

       <button type="submit" ng-disabled="userForm.$invalid">Register</button>
     </td>
   </tr>
   </table>
 
 </form>
 </div>
  
 <script type="text/javascript">
 //defining module
 var app = angular.module('app', []);
 
 //creating custom directive
 app.directive('ngCompare', [function () {
 return {
           require: 'ngModel',
           link: function (scope, elem, attrs, ctrl) {
                 var firstfield = "#" + attrs.ngCompare;
	 
                 //second field key up
                 elem.on('keyup', function () {
                 scope.$apply(function () {
                 var isMatch = elem.val() === $(firstfield).val();
                 ctrl.$setValidity('valueMatch', isMatch);
				 console.log(firstfield);
                 });
                 });

                 
               }
         }
 }]);
 
 // creating angular controller
 app.controller('Ctrl', function ($scope) {
 
   // function to submit the form
   $scope.submitForm = function () {

   // check to make sure the form is completely valid
   if ($scope.userForm.$valid) {
       alert('form is submitted');
   }
 }});
</script>
</body>
</html>