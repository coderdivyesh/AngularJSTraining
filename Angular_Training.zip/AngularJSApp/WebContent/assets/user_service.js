angular.module('sermodule' ,[])
.service('userservice',function(){
	
	var contacts=[{'id':0,
		'name':'manager',
		'pass':'test',
		'cpass':'test',
		'doj':'11/11/2016',
		'income':5000,
		'email':'name@manager.com'},{'id':1,
			'name':'employee',
			'pass':'test',
			'cpass':'test',
			'doj':'11/11/2016',
			'income':10000,
			'email':'name@manager.com'},{'id':2,
				'name':'HR',
				'pass':'test',
				'cpass':'test',
				'doj':'11/11/2016',
				'income':30000,
				'email':'name@manager.com'},{'id':4,
					'name':'employee',
					'pass':'test',
					'cpass':'test',
					'doj':'11/11/2016',
					'income':20000,
					'email':'name@manager.com'}];
	var uid=1;

	this.showUsers=function(){
		
		return contacts;
	}
	
	this.addUser= function(contact){
		
		if(contact.id == null){
			contacts.id = uid++;
			contacts.push(contact); 
		}
		else{
		for(i in contacts){
			if(contacts[i].id == contact.id){
				contacts[i] = contact;
			}
			
			
		}
	}
}

	
	this.deleteUser= function(id){
		
		for(i in contacts){
			if(contacts[i].id == id){
				
				contacts.splice(i,1);
				contact={};
			}
			
		}
		
		
	}
	
	
	
	this.editUser= function(id){
		
		for(i in contacts){
			
			if(contacts[i].id == id){
				return contacts[i];
			}
		}
		
		
		
	}
});


